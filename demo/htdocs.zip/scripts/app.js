window.addEventListener("DOMContentLoaded", init);

function init() {
    var box = document.getElementById("box");
    box.style.left = 0;
    box.style.top = 0;

    window.addEventListener("keyup", function(tuzik) {
        if (tuzik.keyCode == 37) {
            box.style.left = (parseInt(box.style.left) - 30) + "px";
        }
        if (tuzik.keyCode == 39) {
            box.style.left = (parseInt(box.style.left) + 30) + "px";
        }
        if (tuzik.keyCode == 38) {
            box.style.top = (parseInt(box.style.top) - 30) + "px";
        }
        if (tuzik.keyCode == 40) {
            box.style.top = (parseInt(box.style.top) + 30) + "px";
        }
    });
}